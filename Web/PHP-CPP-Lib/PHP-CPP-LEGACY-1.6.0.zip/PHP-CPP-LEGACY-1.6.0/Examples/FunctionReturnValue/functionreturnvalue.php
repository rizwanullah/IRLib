<?php
/**
 *  functionreturnvalue.php
 *  @author Jasper van Eck<jasper.vaneck@copernica.com>
 * 
 *  An example file to show the working of a function call with a return value.
 */

/**
 *  Run a function which returns a value.
 */
echo my_return_value_function() . "\n";
