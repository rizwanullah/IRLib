<?php
/*
 *  functionvoid.php
 *  @author Jasper van Eck<jasper.vaneck@copernica.com>
 * 
 *  An example file to show the working of a void function call.
 */

/*
 *  Run the function with the given name. As you can see, the given name 
 *  can be different from the actual function name.
 */
my_void_function();
